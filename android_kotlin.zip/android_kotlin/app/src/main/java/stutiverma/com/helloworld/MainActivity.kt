package stutiverma.com.helloworld

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.view.ViewCompat.getRotation
import android.view.Display
import android.view.WindowManager
import android.graphics.drawable.Drawable
import android.widget.LinearLayout



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val linearLayout = findViewById(R.id.layout) as LinearLayout
        val res = resources
        val portrait = res.getDrawable(R.drawable.trees)
        val landscape = res.getDrawable(R.drawable.fountain)

        val window = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = window.defaultDisplay
        val num = display.rotation
        if (num == 0) {
            linearLayout.setBackgroundDrawable(portrait)
        } else if (num == 1 || num == 3) {
            linearLayout.setBackgroundDrawable(landscape)
        } else {
            linearLayout.setBackgroundDrawable(portrait)
        }
    }
}
